pub mod descent_methods;
pub mod minimize;
pub mod one_dimension_searchers;
pub mod penalty_methods;
pub mod variable_metric_methods;
